﻿namespace Contact_app
{


    partial class AppData
    {
    }
}
